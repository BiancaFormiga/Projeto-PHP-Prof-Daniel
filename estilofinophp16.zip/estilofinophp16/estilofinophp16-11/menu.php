<div>
  <nav>
    <!--<img src="./imgs/2.png" alt="" class="menu-logo">-->
    <ul class="menu">
      <li><a href="?pg=inicio">Home</a></li>
      <li><a href="index.php">Blusas</a></li>
      <li><a href="?pg=blazers">Blazers</a></li>
      <li><a href="?pg=calças">Calças</a></li>
      <li><a href="?pg=shorts">Shorts</a></li>
      <li><a href="?pg=acessorios">Acessórios</a></li>
      <li><a href="?pg=sapatos">Sapatos</a></li>
      <li><a href="?pg=faleconosco">Fale Conosco</a></li>
  </ul>
  </nav>
</div>