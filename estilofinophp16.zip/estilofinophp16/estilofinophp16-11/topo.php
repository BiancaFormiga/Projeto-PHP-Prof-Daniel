<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estilo Fino</title>
    <link rel="stylesheet" href="./css/css.css">
    <link rel="stylesheet" href="./css/form.css">
    <link rel="stylesheet" href="./css/quem-sou.css">
    <link rel="stylesheet" href="./css/clientes.css">
</head>
<body>
	<div>
        <div style="font-size: 27px; text-align: center;  box-sizing: border-box; ">
            <img src="./Imagens EF/logo 1.png" alt="Estilo Fino" class="menu-logo" style="width: 350px; height: 250px; style=border: none; position: top; top: 1% ">
            <div style="font-size: 24px; text-align: center; width: 20%; display: inline-block; position: absolute; right: 1% ">
                <img src="./imagens/favoritos.png" alt="Estilo Fino"  class="menu-logo" style="width: 50px;">
                <img src="./imagens/carrinho.png" alt="" class="menu-logo" style="width: 50px;">
                <img src="./imagens/perfil.png" alt="" class="menu-logo" style="width: 50px;">
            </div>
        </div> 
		<div id="header">
            <?php
                include_once("menu.php");
            ?>
	    </div>
	</div>