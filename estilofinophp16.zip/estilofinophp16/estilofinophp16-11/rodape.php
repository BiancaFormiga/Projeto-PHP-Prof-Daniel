	<div>
		<div class="footer">
	    	<p class="p-1">Contate-nos!</p> 
			<div class="imagem-link">
            	<a href="https://chat.whatsapp.com/B8xflRrIW4S3HYGCMXwClB">
           		<img src="./imagens/whatsapp.png" alt="Whatsapp"></a>
		   		<a href="https://www.instagram.com/unipetech/">
		   		<img src="./imagens/instagram.png" alt="Instagram"> </a>
		   		<a href="https://www.google.com/intl/pt-BR/gmail/about/">
		   		<img src="./imagens/email.png" alt="E-mail"></a>
		   		<img src="./imagens/telefone.png" alt="Telefone">
	       </div>
		</div>
	</div>
</body>
</html>